## roles

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| fetch-role | Function |  | 自定义接口，返回一个Promise对象，未使用框架服务时必填。 |
| popper-append-to-body | boolean | true | 是否将弹出框插入至 body 元素。在弹出框的定位出现问题时，可将该属性设置为 false (可参考 select 组件) |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| change |  | 选中值发生变化时触发 |
