## rich-text-editor

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| customToolBar | Array | [] | 传入需要展示的工具栏按钮配置，设置时，显示全量的工具栏。可配置的项目有：'bold','italic', 'underline', 'strike', 'quote', 'code', 'codeBlock', 'unorderedlist', 'orderedlist', 'taskList', 'subscript', 'superscript', 'undo', 'redo', 'left', 'center', 'right', 'h-box', 'font-size', 'line-height', 'highlight', 'color', 'backgroundColor', 'formatClear', 'link', 'unlink', 'img', 'table' |
| modelValue | string |  | 默认富文本内容 |
| options | Object | {} | 参见tiptap扩展说明，会覆盖useEditor配置项 |
| placeholder | Stirng |  | 占位符，在v-model为空时展示 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| beforeCreate |  | 当编辑器视图创造之前，将会触发该事件 |
| blur |  | 当编辑器失去焦点，将会触发该事件 |
| create |  | 当编辑器已经挂载好，将会触发该事件 |
| destroy |  | 当编辑器编辑器销毁了，将会触发该事件 |
| focus |  | 当编辑器获得焦点，将会触发该事件 |
| selectionUpdate |  | 当编辑器选区改变，将会触发该事件 |
| transaction |  | 当编辑器状态改变，将会触发该事件。 |
| update |  | 当编辑器状态改变完成后，将会触发该事件 |

### Slots

| 插槽名 | 说明 |
|--------|------|
| toolBar | toolBar添加按钮,会传出editor实例，详情见tiptap |
