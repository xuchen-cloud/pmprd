## Tabbar

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| active-color | string |  | <p>选中标签的颜色</p> |
| border | boolean |  | <p>是否显示外边框，该属性默认为true</p> |
| inactive-color | string |  | <p>未选中标签的颜色</p> |
| item-list | Object[] | [] | 设置底部导航虚幻遍历需要放的数组; |
| show-number | number | 5 | 设置底部导航需要展示的项数 |
| v-model | Number \| String | 0 | 设置底部导航双向数据绑定 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| change | Function() | <p>切换标签时触发,value: 当前选中标签的名称或索引值</p> |

### Slots

| 插槽名 | 说明 |
|--------|------|
| default | 底部导航每一项 |

## TabbarItem

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| badge | Number \| String |  | 设置底部导航选项徽标 |
| custom-icon | boolean |  | 设置底部导航个性化图标 |
| dot | boolean |  | 设置底部导航选项点 |
| icon | Object |  | 设置底部导航上自定义图标 |
| name | Number \| String |  | 设置底部导航选项标题 |
| text | string |  | 设置底部导航循环时设定的标题 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| click | Function() | 选项点击时触发的事件 |

### Slots

| 插槽名 | 说明 |
|--------|------|
| default | 底部导航每一项 |
