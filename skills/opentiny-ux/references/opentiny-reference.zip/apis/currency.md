## currency

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| clearable | boolean | 该属性的默认值为 true | 是否显示清除按钮 |
| disabled | boolean | 该属性的默认值为 false | 禁用 |
| fetch-currency | Function |  | 自定义金额查询接口，返回一个Promise对象 |
| fields | object |  | 自定义数据映射，在没有使用框架服务时必填 |
| modelValue / v-model | string , number |  | 设置下拉框的值。 |
| placeholder | string |  | 设置输入框内的提示占位文本。 |
| popper-append-to-body | boolean | 该属性的默认值为 true | 是否将弹出框插入至 body 元素。在弹出框的定位出现问题时，可将该属性设置为 false (可参考 select 组件) |
| popper-class | string |  | 为 popper 添加类名(可参考 popover 组件) |
| size | string |  | 输入框尺寸，只在 type!="textarea" 时有效;该属性的可选值为 medium / small / mini |
| set-default | boolean | false | 是否开启设置默认币种，默认值为 false |
| set-default-currency | function |  | 设置默认币种的自定义方法 |
| fetch-default-currency | function |  | 设置默认币种的服务 |
| label | string |  | 显示标题，设置 shape='filter' 属性切换至过滤器模式时有效，可参考 FilterBox 组件属性 |
| drop-style | object | {} | 自定义下拉选项样式 |
| shape | string |  | 通过 shape='filter' 属性切换至过滤器模式 |
| tip | string |  | 显示提示信息，设置 shape='filter' 属性切换至过滤器模式时有效，可参考 FilterBox 组件属性 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| change |  | <br>              arg1:{Any\|Array 单选并且未指定渲染类型时，是选中项的值字段，此时没有arg2参数；多选并且未指定渲染类型时，是选中项值字段组成的数组，此时没有arg2参数；单选并且渲染类型为树或者表格时，是选中项对象，此时没有arg2参数；多选并且渲染类型为树或者表格时，是选中项对象值字段组成的数组，此时有arg2参数；}，<br><br>              arg2:{Array 多选并且渲染类型为树或者表格时，是选中项对象组成的数组}<br>             |
