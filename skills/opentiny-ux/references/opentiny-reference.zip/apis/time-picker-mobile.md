## time-picker-mobile

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| v-model | Array |  | 绑定值 |
| visible | Boolean |  | 是否弹出面板 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| update:visible |  | 显示或隐藏面板时触发 |

### Slots

| 插槽名 | 说明 |
|--------|------|
| default | 组件默认插槽，设置 type 为 action 启用操作列表模式会提供参数 data 列表项和 index 列表索引 |
