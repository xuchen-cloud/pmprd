## record

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| is-hwh5 | Boolean |  | 是否为H5页面 |
| lock-scroll | Boolean |  | 设置页面锁住滚动，默认值为 true  |
| v-model | Boolean |  | 数据绑定 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| confirm |  | 设置结束录音事件 |
