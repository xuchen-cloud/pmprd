## amount

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| currency | string | 该属性的默认值为 CNY |  |
| date | string |  | 设置弹出框内显示日期框。值可设置为 string 或者 Date() 类型。 |
| digits | number | 该属性的默认值为 2 | 设置小数点位数，默认为 2 位。 |
| disabled | boolean | 该属性的默认值为 false | 设置是否禁用，默认为 false。 |
| fetchCurrency | Function |  | 自定义金额组件的请求服务接口，fetchCurrency返回一个Promise对象  |
| fields | object |  | 自定义金额组件数据映射，在没有使用框架服务时必填 |
| format | object |  | 数字格式化置项，可配置如下字段：;{<br> fraction: 4, // 保留小数位数<br> rounding: 0, // 舍入点，0-9之间的数字，如配置为7时则为6舍7入，默认为5（四舍五入）;配置为0或>9将会进行截取<br> prefix: '$', // 前置标识<br> groupSize: 3, // 整数部分分组间隔，即第一个分组位数<br> secondaryGroupSize: 2, // 整数部分第二级分组间隔，不设置或为0时 自动取groupSize<br> groupSeparator: ',', // 整数部分分组分隔符<br> decimalSeparator: '.', // 小数点符号<br> fractionGroupSize: 0, // 小数部分分组间隔<br> fractionGroupSeparator: ' ', // 小数分组分隔符<br> suffix: '@' // 后置标识<br> } |
| max-len | number | 该属性的默认值为 15 | 整数位最大长度，默认为 15 位。 |
| negative | boolean |  | 是否可为负数，默认为 true ，可设为负数。 |
| num-allow-empty | Boolean |  | 设置数值允许为空 |
| placeholder | string |  | 当数据为空时的占位符 |
| popper-append-to-body | boolean | 该属性的默认值为 true | 是否将弹出框插入至 body 元素。在弹出框的定位出现问题时，可将该属性设置为 false (可参考 select 组件) |
| popper-class | string |  | 为 popper 添加类名(可参考 popover 组件) |
| rounding | boolean |  | 控制输入金额四舍五入。 |
| size | string |  | 设置组件大小 |
| value | string , number |  | 设置金额组件的值。 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| change |  | 当组件的值发生变化时会触发该事件。 |
