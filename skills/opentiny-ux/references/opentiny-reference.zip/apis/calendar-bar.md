## calendarBar

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| cascaderPosition | Object | {} | 改变年月选择的位置 |
| config | Object | {} | 传入用户日期配置信息 |
| v-model | String |  | 数据绑定 |

### Methods

| 方法名 | 返回值 | 说明 |
|--------|--------|------|
| expand |  | 日历栏展开或收起时触发的事件 |
