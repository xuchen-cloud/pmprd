## date-picker-mobile

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| lock-scroll | String |  | 弹出面板是否锁定浏览器滚动条，默认值为 true |
| picker-options | Object |  | 日期选择器特有的选项，该属性的默认值为 { disabledDate: null }，其中 disabledDate 可以设置日期范围限制 |
| title | String |  | 面板标题 |
| type | String |  | 组件类型，默认值为 date |
| v-model | Number, String, Array, Date |  | 绑定值 |
| visible | Boolean |  | 是否弹出面板 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| click |  | 选择日期时触发 |
| confirm |  | 面板确认时触发 |
| time-confirm |  | 时间面板确认时触发 |
| update:visible |  | 显示或隐藏面板时触发 |

### Methods

| 方法名 | 返回值 | 说明 |
|--------|--------|------|
| confirm |  | 确认并关闭面板 |
| formatDate(date, dateFormat) |  | 日期格式化方法，例如：formatDate('2022/11/30', 'yyyy年MM月dd日') |

### Slots

| 插槽名 | 说明 |
|--------|------|
| default | 日期单元格插槽，参数：data 当前日期数据 |
