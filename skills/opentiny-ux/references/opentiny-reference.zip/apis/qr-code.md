## qr-code

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| bordered | boolean | true | 是否有边框 |
| color | string | '#000' | 二维码颜色, 仅支持十六进制 |
| icon | string |  | 二维码中图片的地址（目前只支持图片地址） |
| icon-size | number | 50 | 二维码中图片的大小，icon 覆盖面积不能超过二维码面积的 30%， 否则影响扫码 |
| level | string | 'Medium' | 二维码纠错等级, 可选 'Low' \| 'Medium' \| 'Quality' \| 'High' |
| size | number | 200 | 二维码大小 |
| value | string |  | 扫描后的文本 |

### Events

| 事件名 | 回调参数 | 说明 |
|--------|----------|------|
| change | () => void | 二维码发生变化后的回调 |
