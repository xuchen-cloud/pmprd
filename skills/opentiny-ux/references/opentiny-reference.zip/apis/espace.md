## espace

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| data | Array , object |  | 设置组件数据，数组对象中包含选项有 type、value、icon。type 的可选择值有：im、sip、mailto |
