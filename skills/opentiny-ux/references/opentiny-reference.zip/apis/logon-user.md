## logon-user

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| getUserInfo | Function |  | 配置查询系统当前用户接口 |
