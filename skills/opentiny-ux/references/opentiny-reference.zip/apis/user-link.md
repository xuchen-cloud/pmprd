## user-link

### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| cache | boolean | 该属性的默认值为 true | 是否开启用户数据缓存，默认为 ture 缓存用户数据 |
| cache-fields | Array |  | 自定义缓存的字段 |
| cache-key | string | 该属性的默认值为 tiny-user | 自定义缓存 key 默认值为 tiny-user |
| fetchUser | Function |  | 配置通过员区号查询用户信息（展示在卡片上） |
| fetchW3Accounts | Function |  | 自定义配置批量查询用户信息服务 |
| getUserImageUrl | Function |  | 自定义配置获取用户头像服务 |
| text-field | string | 该属性的默认值为 userCN | 设置下拉框的文本对应的数据源的字段名称 |
| text-split | string | 该属性的默认值为 , | 在多选的情况下，设置输入框显示多个文本时的分隔符 |
| value | string |  | 配置默认值，默认为空 |
| value-field | string | 该属性的默认值为 userId | 设置下拉框的值所对应数据源的字段名称 |
| value-split | string | 该属性的默认值为 , | 在多选的情况下，设置输入框显示多个文本时的分隔符，默认为 ; 分号;在多选的情况下，设置输入框显示多个文本时的分隔符，默认为 , 逗号 |
